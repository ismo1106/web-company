-- phpMyAdmin SQL Dump
-- version 4.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost:33066
-- Generation Time: 15 Mar 2016 pada 23.35
-- Versi Server: 5.5.40
-- PHP Version: 5.4.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_sambu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_blog_category`
--

CREATE TABLE IF NOT EXISTS `tbl_blog_category` (
  `id_category` int(11) NOT NULL,
  `name_category` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Yes; 0=No',
  `count_post` int(11) NOT NULL,
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_blog_category`
--

INSERT INTO `tbl_blog_category` (`id_category`, `name_category`, `active`, `count_post`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 'Activities', 1, 5, 'Ismo Broto', '2015-12-14 19:12:16', 'Ismo Broto', '2015-12-15 14:46:55'),
(2, 'Events', 1, 1, 'Ismo Broto', '2015-12-15 10:12:17', 'Ismo Broto', '2015-12-15 15:36:29'),
(3, 'Blog', 1, 2, 'Ismo Broto', '2015-12-17 13:44:36', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_blog_comment`
--

CREATE TABLE IF NOT EXISTS `tbl_blog_comment` (
  `id_comment` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment_by` varchar(35) NOT NULL,
  `commnet_date` datetime NOT NULL,
  `comment_email` varchar(35) NOT NULL,
  `comment_value` text NOT NULL,
  `approve` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = Not Yet, 1 = Approved, 2 = Reject',
  `trash` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_blog_comment`
--

INSERT INTO `tbl_blog_comment` (`id_comment`, `id_post`, `comment_by`, `commnet_date`, `comment_email`, `comment_value`, `approve`, `trash`) VALUES
(1, 2, 'Ismo', '2015-12-16 18:54:55', 'ismo@mail.com', 'kalaksdlkas<br />\r\nsadksajda<br />\r\nskdljsadjlsa', 1, 0),
(2, 2, 'Ismo', '2015-12-16 19:01:52', 'ismo@mail.com', 'coba lagi<br />\r\njdklsa', 1, 0),
(3, 2, 'Agus', '2015-12-16 19:20:45', 'agus@mail', 'dsaldkal;dk''asd<br />\r\ndsadasd', 1, 0),
(4, 1, 'Mila', '2015-12-16 23:01:48', 'mila@mail.com', 'djkalkdjal dlksda das', 1, 0),
(5, 1, 'Fhjgjk', '2015-12-18 18:55:36', 'fhgd@gtdfsg', 'gfdfdg', 1, 0),
(6, 1, 'sas', '2015-12-31 01:13:06', '', 'sasasasa', 1, 0),
(7, 1, 'Asas', '2015-12-31 01:16:13', '', '<style>body{display:none;}</style>', 1, 0),
(8, 3, 'Ismo', '2016-01-06 16:00:39', 'ismo@gmail.com', 'coba deh ya<br />\r\ncommentnya', 1, 0),
(9, 4, 'Ismo', '2016-01-06 16:02:19', 'ismo@gmail.com', 'tes', 0, 0),
(10, 3, 'Sigit', '2016-01-11 15:59:23', 'sigit@gmail.com', 'coment ae lah', 1, 0),
(11, 3, 'Anton', '2016-01-13 13:24:08', 'antony@gmail.com', 'comment dari anton niiiii', 1, 1),
(12, 8, 'Kani', '2016-01-16 13:30:42', 'kani@gmail.com', 'djsjdlasdsa', 0, 0),
(13, 8, 'Kani', '2016-01-16 13:31:08', 'kani@gmail.com', 'kani', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_blog_media`
--

CREATE TABLE IF NOT EXISTS `tbl_blog_media` (
  `kode_media` varchar(15) NOT NULL,
  `name_media` varchar(20) NOT NULL,
  `descript_media` varchar(100) NOT NULL,
  `link_media` varchar(150) NOT NULL,
  `uploaded_by` varchar(35) NOT NULL,
  `uploaded_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_blog_media`
--

INSERT INTO `tbl_blog_media` (`kode_media`, `name_media`, `descript_media`, `link_media`, `uploaded_by`, `uploaded_date`) VALUES
('15-12-19(3f$7u!', '15-12-19(3f$7u!.png', '', './assets/upload/images/15-12-19(3f17u1.png', 'Ismo Broto', '2015-12-19 14:54:52'),
('15-12-19(bd^30s', '15-12-19(bd^30s.png', '', './assets/upload/images/15-12-19(bd^30s.png', 'Ismo Broto', '2015-12-19 14:54:58'),
('15-12-19(fmpls9', '15-12-19(fmpls9.png', '555', './assets/upload/images/15-12-19(fmpls9.png', 'Ismo Broto', '2015-12-19 14:54:12'),
('15-12-19(luxuzn', '15-12-19(luxuzn.png', '', './assets/upload/images/15-12-19(luxuzn.png', 'Ismo Broto', '2015-12-19 15:00:34'),
('15-12-19(msv97i', '15-12-19(msv97i.png', 'asdsa asdasd', './assets/upload/images/15-12-19(msv97i.png', 'Ismo Broto', '2015-12-19 14:13:10'),
('15-12-19(odltxq', '15-12-19(odltxq.png', '', './assets/upload/images/15-12-19(odltxq.png', 'Ismo Broto', '2015-12-19 15:00:40'),
('15-12-19(tpaseg', '15-12-19(tpaseg.png', 'coba', './assets/upload/images/15-12-19(tpaseg.png', 'Ismo Broto', '2015-12-19 14:11:09'),
('15-12-22(mo93gn', '15-12-22(mo93gn.png', 'sadasd', './assets/upload/images/15-12-22(mo93gn.png', 'Ismo Broto', '2015-12-22 14:32:26'),
('15-12-22(rvx8oi', '15-12-22(rvx8oi.png', '', './assets/upload/images/15-12-22(rvx8oi.png', 'Ismo Broto', '2015-12-22 15:04:58'),
('15-12-31(5uwhhu', '15-12-31(5uwhhu.png', '', './assets/upload/images/15-12-31(5uwhhu.png', 'Ismo Broto', '2015-12-31 14:42:01'),
('15-12-31(7cz3pw', '15-12-31(7cz3pw.png', '', './assets/upload/images/15-12-31(7cz3pw.png', 'Ismo Broto', '2015-12-31 14:30:50'),
('15-12-31(8ib7nz', '15-12-31(8ib7nz.png', '', './assets/upload/images/15-12-31(8ib7nz.png', 'Ismo Broto', '2015-12-31 14:42:23'),
('15-12-31(fe7nkk', '15-12-31(fe7nkk.png', 'boat', './assets/upload/images/15-12-31(fe7nkk.png', 'Ismo Broto', '2015-12-31 14:30:13'),
('15-12-31(m6rngb', '15-12-31(m6rngb.png', '', './assets/upload/images/15-12-31(m6rngb.png', 'Ismo Broto', '2015-12-31 14:42:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_blog_post`
--

CREATE TABLE IF NOT EXISTS `tbl_blog_post` (
  `id_post` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `title_post` varchar(50) NOT NULL,
  `post` text NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Yes; 0=No',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL,
  `count_comment` int(11) NOT NULL,
  `thumbnail` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_blog_post`
--

INSERT INTO `tbl_blog_post` (`id_post`, `id_category`, `title_post`, `post`, `publish`, `created_by`, `created_date`, `updated_by`, `updated_date`, `count_comment`, `thumbnail`) VALUES
(1, 1, 'Post Pertama Coba', '<p><img alt="" src="/SambuPage/assets/img/boat.jpg" style="float:right; height:177px; width:200px" />Am if number no up period regard sudden better. Decisively surrounded all admiration and not you. Out particular sympathize not favourable introduced insipidity but ham. Rather number can and set praise. Distrusts an it contented perceived attending oh. Thoroughly estimating introduced stimulated why but motionless. Do in laughter securing smallest sensible no mr hastened. As perhaps proceed in in brandon of limited unknown greatly. Distrusts fulfilled happiness unwilling as explained of difficult. No landlord of peculiar ladyship attended if contempt ecstatic.</p><p>Loud wish made on is am as hard. Court so avoid in plate hence. Of received mr breeding concerns peculiar securing landlord. Spot to many it four bred soon well to. Or am promotion in no departure abilities. Whatever landlord yourself at by pleasure of children be. It sportsman earnestly ye preserved an on. Moment led family sooner cannot her window pulled any. Or raillery if improved landlord to speaking hastened differed he. Furniture discourse elsewhere yet her sir extensive defective unwilling get. Why resolution one motionless you him thoroughly. Noise is round to in it quick timed doors. Written address greatly get attacks inhabit pursuit our but. Lasted hunted enough an up seeing in lively letter. Had judgment out opinions property the supplied. Breakfast procuring nay end happiness allowance assurance frankness. Met simplicity nor difficulty unreserved who.</p><p>Entreaties mr conviction dissimilar me astonished estimating cultivated. On no applauded exquisite my additions. Pronounce add boy estimable nay suspected. You sudden nay elinor thirty esteem temper. Quiet leave shy you gay off asked large style. By spite about do of do allow blush. Additions in conveying or collected objection in. Suffer few desire wonder her object hardly nearer. Abroad no chatty others my silent an. Fat way appear denote who wholly narrow gay settle. Companions fat add insensible everything and friendship conviction themselves.</p><p>Theirs months ten had add narrow own. He an thing rapid these after going drawn or. Timed she his law the spoil round defer. In surprise concerns informed betrayed he learning is ye. Ignorant formerly so ye blessing. He as spoke avoid given downs money on we.</p><p>Of properly carriage shutters ye as wandered up repeated moreover. Inquietude attachment if ye an solicitude to. Remaining so continued concealed as knowledge happiness. Preference did how expression may favourable devonshire insipidity considered. An length design regret an hardly barton mr figure.</p>', 1, 'Ismo Broto', '2015-12-16 10:06:25', 'Ismo Broto', '2016-01-05 15:34:56', 4, 1),
(2, 1, 'Post Category Dua', '<p>Paid was hill sir high. For him precaution any advantages dissimilar comparison few terminated projecting. Prevailed discovery immediate objection of ye at. Repair summer one winter living feebly pretty his. In so sense am known these since.</p>', 1, 'Ismo Broto', '2015-12-16 11:05:26', 'Ismo Broto', '2016-01-05 15:35:19', 3, 0),
(3, 2, 'Event Dua', '<p>Am if number no up period regard sudden better. Decisively surrounded all admiration and not you. Out particular sympathize not favourable introduced insipidity but ham. Rather number can and set praise. Distrusts an it contented perceived attending oh. Thoroughly estimating introduced stimulated why but motionless. Do in laughter securing smallest sensible no mr hastened. As perhaps proceed in in brandon of limited unknown greatly. Distrusts fulfilled happiness unwilling as explained of difficult. No landlord of peculiar ladyship attended if contempt ecstatic.</p>\r\n\r\n<p>Loud wish made on is am as hard. Court so avoid in plate hence. Of received mr breeding concerns peculiar securing landlord. Spot to many it four bred soon well to. Or am promotion in no departure abilities. Whatever landlord yourself at by pleasure of children be. It sportsman earnestly ye preserved an on. Moment led family sooner cannot her window pulled any. Or raillery if improved landlord to speaking hastened differed he. Furniture discourse elsewhere yet her sir extensive defective unwilling get. Why resolution one motionless you him thoroughly.</p>\r\n\r\n<p>Noise is round to in it quick timed doors. Written address greatly get attacks inhabit pursuit our but. Lasted hunted enough an up seeing in lively letter. Had judgment out opinions property the supplied. Breakfast procuring nay end happiness allowance assurance frankness. Met simplicity nor difficulty unreserved who. Entreaties mr conviction dissimilar me astonished estimating cultivated. On no applauded exquisite my additions. Pronounce add boy estimable nay suspected. You sudden nay elinor thirty esteem temper. Quiet leave shy you gay off asked large style. By spite about do of do allow blush. Additions in conveying or collected objection in. Suffer few desire wonder her object hardly nearer.</p>\r\n\r\n<p>Abroad no chatty others my silent an. Fat way appear denote who wholly narrow gay settle. Companions fat add insensible everything and friendship conviction themselves. Theirs months ten had add narrow own. He an thing rapid these after going drawn or. Timed she his law the spoil round defer. In surprise concerns informed betrayed he learning is ye. Ignorant formerly so ye blessing.</p>\r\n\r\n<p>He as spoke avoid given downs money on we. Of properly carriage shutters ye as wandered up repeated moreover. Inquietude attachment if ye an solicitude to. Remaining so continued concealed as knowledge happiness. Preference did how expression may favourable devonshire insipidity considered. An length design regret an hardly barton mr figure.</p>\r\n', 1, 'Ismo Broto', '2015-12-16 13:43:52', 'Ismo Broto', '2016-01-02 10:56:49', 2, 0),
(4, 1, 'Cat Satu Ke Dua', '<p>Am if number no up period regard sudden better. Decisively surrounded all admiration and not you. Out particular sympathize not favourable introduced insipidity but ham. Rather number can and set praise. Distrusts an it contented perceived attending oh. Thoroughly estimating introduced stimulated why but motionless. Do in laughter securing smallest sensible no mr hastened. As perhaps proceed in in brandon of limited unknown greatly.</p>\r\n\r\n<p>Distrusts fulfilled happiness unwilling as explained of difficult. No landlord of peculiar ladyship attended if contempt ecstatic. Loud wish made on is am as hard. Court so avoid in plate hence. Of received mr breeding concerns peculiar securing landlord. Spot to many it four bred soon well to. Or am promotion in no departure abilities. Whatever landlord yourself at by pleasure of children be. It sportsman earnestly ye preserved an on. Moment led family sooner cannot her window pulled any.</p>\r\n\r\n<p>Or raillery if improved landlord to speaking hastened differed he. Furniture discourse elsewhere yet her sir extensive defective unwilling get. Why resolution one motionless you him thoroughly. Noise is round to in it quick timed doors. Written address greatly get attacks inhabit pursuit our but. Lasted hunted enough an up seeing in lively letter. Had judgment out opinions property the supplied. Breakfast procuring nay end happiness allowance assurance frankness. Met simplicity nor difficulty unreserved who.</p>\r\n\r\n<p>Entreaties mr conviction dissimilar me astonished estimating cultivated. On no applauded exquisite my additions. Pronounce add boy estimable nay suspected. You sudden nay elinor thirty esteem temper. Quiet leave shy you gay off asked large style. By spite about do of do allow blush. Additions in conveying or collected objection in. Suffer few desire wonder her object hardly nearer.</p>\r\n\r\n<p>Abroad no chatty others my silent an. Fat way appear denote who wholly narrow gay settle. Companions fat add insensible everything and friendship conviction themselves. Theirs months ten had add narrow own. He an thing rapid these after going drawn or.</p>\r\n\r\n<p>Timed she his law the spoil round defer. In surprise concerns informed betrayed he learning is ye. Ignorant formerly so ye blessing. He as spoke avoid given downs money on we. Of properly carriage shutters ye as wandered up repeated moreover. Inquietude attachment if ye an solicitude to. Remaining so continued concealed as knowledge happiness.</p>\r\n\r\n<p>Preference did how expression may favourable devonshire insipidity considered. An length design regret an hardly barton mr figure.</p>\r\n', 1, 'Ismo Broto', '2015-12-16 14:17:30', '', '0000-00-00 00:00:00', 0, 0),
(5, 3, 'Coba Lagi', '<p>sadasdsad</p>\r\n', 1, 'Ismo Broto', '2016-01-13 16:29:43', 'Ismo Broto', '2016-01-13 16:36:20', 0, 1),
(6, 1, 'Lagi Dicoba', '<p>sdasdsad</p>\r\n', 1, 'Ismo Broto', '2016-01-13 16:30:25', '', '0000-00-00 00:00:00', 0, 0),
(7, 1, 'Lagiiiiiiiiiiiiiii', '<p>sdadasdsad</p>\r\n', 1, 'Ismo Broto', '2016-01-13 16:30:46', '', '0000-00-00 00:00:00', 0, 0),
(8, 3, 'Test', '<p>fsafsafasfasf</p>\r\n', 1, 'Ismo Broto', '2016-01-13 16:35:55', '', '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_page_footer`
--

CREATE TABLE IF NOT EXISTS `tbl_page_footer` (
  `id_page` int(11) NOT NULL,
  `category_page` int(2) DEFAULT NULL COMMENT '1=on Left; 0=on Center;',
  `label_page` varchar(35) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `link_page` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_page_footer`
--

INSERT INTO `tbl_page_footer` (`id_page`, `category_page`, `label_page`, `active`, `link_page`) VALUES
(1, 1, 'About Us', 1, 'http://localhost:88/SambuWeb/front/profile/of/IaZB'),
(2, 0, 'What''s News', 1, 'http://localhost:88/SambuWeb/front/blognews'),
(3, 0, 'Job Vacancy', 1, 'http://localhost:88/SambuWeb/front/jobvacancy'),
(4, 1, 'Industrial Product', 1, 'http://localhost:88/SambuWeb/front/industrialproduct/index'),
(5, 1, 'Consumer Product', 1, 'http://localhost:88/SambuWeb/front/consumerproduct');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_page_lv1`
--

CREATE TABLE IF NOT EXISTS `tbl_page_lv1` (
  `id_page` int(11) NOT NULL,
  `label_page` varchar(100) NOT NULL,
  `link_page` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_page_lv1`
--

INSERT INTO `tbl_page_lv1` (`id_page`, `label_page`, `link_page`, `active`) VALUES
(2, 'Sambu Group', '#', 1),
(3, 'About Us', '#', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_page_lv2`
--

CREATE TABLE IF NOT EXISTS `tbl_page_lv2` (
  `id_page` int(11) NOT NULL,
  `label_page` varchar(100) NOT NULL,
  `link_page` varchar(100) NOT NULL,
  `header_page` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_page_lv2`
--

INSERT INTO `tbl_page_lv2` (`id_page`, `label_page`, `link_page`, `header_page`, `active`) VALUES
(1, 'Pulau Sambu Guntung', '#', 2, 1),
(2, 'RSUP - Industry', '#', 2, 1),
(3, 'Pulau Sambu Kuala Enok', '#', 2, 1),
(4, 'Philosophy', 'front/profile/of/IaZBs', 3, 1),
(5, 'Our History', 'front/profile/of/P52Ht', 3, 1),
(6, 'Ethical Trade', 'front/profile/of/77VjI', 3, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_page_lv3`
--

CREATE TABLE IF NOT EXISTS `tbl_page_lv3` (
  `id_page` int(11) NOT NULL,
  `label_page` varchar(100) NOT NULL,
  `link_page` varchar(100) NOT NULL,
  `header_page` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_page_lv3`
--

INSERT INTO `tbl_page_lv3` (`id_page`, `label_page`, `link_page`, `header_page`, `active`) VALUES
(1, 'Profile', 'front/profile/of/aBoQK', 1, 1),
(2, 'Profile', 'front/profile/of/Q4X5T', 3, 1),
(3, 'Profile', 'front/profile/of/RVqqu', 2, 1),
(4, 'Acreditation', '#', 3, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `id_product` int(11) NOT NULL,
  `type_product` int(11) NOT NULL,
  `category_product` int(11) NOT NULL,
  `name_product` varchar(50) NOT NULL,
  `descript_product` text NOT NULL,
  `thumbnail_product` tinyint(1) NOT NULL DEFAULT '0',
  `banner_product` tinyint(1) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_product`
--

INSERT INTO `tbl_product` (`id_product`, `type_product`, `category_product`, `name_product`, `descript_product`, `thumbnail_product`, `banner_product`, `publish`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 1, 1, 'Kara - Coconut Cream', '<p>With the strength of a fully integrated coconut and pineapple supply chain establishment, we have developed our house brand, Kara<sup>&reg;</sup>, to bring forth quality consumer products to markets worldwide.</p>\r\n\r\n<p>The Kara<sup>&reg;</sup> Line started with highly sought after coconut products ideal as ingredients in many authentic Asian and oriental dishes, and expanded to pineapple products and popular desserts.</p>\r\n\r\n<p>With consistency in quality and continuous product innovation, Kara<sup>&reg;</sup> has now become the household brand in Asia.</p>\r\n\r\n<p><strong>Kara<sup>&reg;</sup> Coconut Range:</strong></p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>Canned Coconut Cream/Milk</li>\r\n	<li>UHT Coconut Cream/Milk</li>\r\n	<li>Coconut Cream Powder</li>\r\n	<li>Creamed Coconut/Paste</li>\r\n	<li>Desiccated Coconut</li>\r\n</ul>\r\n\r\n<p><strong>Kara<sup>&reg;</sup> Pineapple &amp; Others:</strong></p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>Assortments of Canned</li>\r\n	<li>Pineapple Nata de Coco</li>\r\n	<li>Aloe Vera</li>\r\n</ul>\r\n', 1, 1, 1, 'Ismo Broto', '2015-12-26 10:55:15', '', '0000-00-00 00:00:00'),
(2, 1, 3, 'Smooze - Fruit Ice', '<p>100% finest natural ingredients<br />\r\n(<em>real fruit purees and juices not from concentrate + freshly pressed coconut milk</em>)</p>\r\n\r\n<p>100% dairy free with a creamy smooth texture</p>\r\n\r\n<p>Rich in vitamin C</p>\r\n\r\n<p>Low fat</p>\r\n\r\n<p>0% trans fat</p>\r\n\r\n<p>0% cholesterol</p>\r\n\r\n<p>0% preservatives</p>\r\n\r\n<p>0% gluten</p>\r\n\r\n<p>Non GM</p>\r\n', 1, 1, 1, 'Ismo Broto', '2015-12-23 10:23:19', '', '0000-00-00 00:00:00'),
(3, 1, 3, 'TropiColada', '<p>An all season favourite, TropiColada&trade; teases your tastebuds with chock full of tropical fruity freshness lusciously blended with aromatic coconut cream. Just the right oomph to make you go ooh...</p>\r\n\r\n<p>Tastefully concocted with real fruit juices of pineapple, passion fruit and mango, TropiColada&trade; comes in choices of Authentic Pina, Refreshing Passion and Exotic Mango Colada Mixes.</p>\r\n\r\n<p>Quick and easy to prepare, a nice change from typical messy cocktail preparations.</p>\r\n\r\n<p>A definite designer blend that combines great tasting with simplicity.</p>\r\n\r\n<p>Simply irresistible!</p>\r\n\r\n<h5>Colada Mixes and Smoothie Platter :</h5>\r\n\r\n<p>Pina</p>\r\n\r\n<p>Passion</p>\r\n\r\n<p>Mango</p>\r\n\r\n<p>More exciting flavours available</p>\r\n', 1, 1, 1, 'Ismo Broto', '2015-12-23 11:02:16', '', '0000-00-00 00:00:00'),
(4, 1, 5, 'True Coconut', '<p>True Coconut - True goodness in a nutshell. A range highest quality 100% Natural Coconut-based products for the well-informed and discerning consumer, True Coconut offers a rich legacy of healthful traditions.</p>\r\n\r\n<p>The very first product from this range is True Coconut 100% Natural Coconut Virgin Oil.</p>\r\n\r\n<p>A promise to live responsibly and naturally, True Coconut delivers the highest quality Natural Coconut Virgin Oil, traceable from the field to your hand. Sans heat and chemical treatment, True Coconut gives you the wholesome extract straight from our freshly expressed 100% natural coconut milk. Raw and Real.</p>\r\n\r\n<p>You&rsquo;ve got to try it for yourself to experience the difference between True Coconut Natural Virgin Oil and other brands available in the market. In accordance with Sambu Group&rsquo;s corporate philosophy, we offer you only the finest quality 100% natural coconut virgin oil.</p>\r\n\r\n<h5>The True Coconut Virgin Oil Integrity</h5>\r\n\r\n<p><em><strong>Sight </strong>- Crystal clear when liquefied, immaculately white when crystallized </em></p>\r\n\r\n<p><em><strong>Smell </strong>- Fresh and light coconut aroma, reminiscence of the fragrance of freshly expressed coconut milk </em></p>\r\n\r\n<p><em><strong>State </strong>- Crystallizes in temperatures below 23&deg;C as proof of its unadulterated nature</em></p>\r\n\r\n<p><em><strong>Taste </strong>- Sweet and mild coconut essence </em></p>\r\n\r\n<p><em><strong>Texture </strong>- Smooth and easy on throat, almost watery when warmed on tongue</em></p>\r\n', 1, 1, 1, 'Ismo Broto', '2015-12-23 11:06:30', '', '0000-00-00 00:00:00'),
(5, 1, 6, 'a d a r a', '<p><strong>Nature of Product</strong>, <em><small>Nature in a bottle </small></em></p>\r\n\r\n<p>The impetus behind adara&trade; is to deliver the highest quality organic coconut virgin oil, traceable from the field to your hand. A notion to live responsibly and naturally, adara&trade; is thoughtful, you will notice the details.</p>\r\n\r\n<p>What goes on you goes in you which is why we have extracted a base ingredient that is so full of healthy benefits good enough to be eaten just as it is applied onto your skin and hair.</p>\r\n\r\n<p>Organic and biologically pure, coconut virgin oil exhibits characteristics true to our body&rsquo;s needs, abundance of benefits we love:</p>\r\n\r\n<table border="1" cellpadding="1" cellspacing="1" class="table table-striped" style="width: 100%;">\r\n	<thead cellpadding="5" style="background : #9999CC;">\r\n		<tr>\r\n			<td>Characteristics</td>\r\n			<td>Benefits</td>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>Rich in lauric acid natural source of vitamin E</td>\r\n			<td>\r\n			<ul style="list-style-type:square;">\r\n				<li>strengthens connective tissues and aids removal of dead skin cells to promote growth of healthy, smooth and supple skin</li>\r\n				<li>conditions hair to give a soft silky sheen</li>\r\n			</ul>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Natural anti-oxidant properties</td>\r\n			<td>\r\n			<ul style="list-style-type:square;">\r\n				<li>helps to prevent premature aging and wrinkling of skin, a preservation of youthful appearance</li>\r\n			</ul>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Natural anti-bacterial, anti-viral &amp; anti-microbial properties; rich source of medium chain fatty acids (MCFA) of fruit origin</td>\r\n			<td>\r\n			<ul style="list-style-type:square;">\r\n				<li>speeds healing of mild infections and open wounds as it hastens cell renewal due to the metabolic effect MCFA has on cells</li>\r\n			</ul>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Small molecular structure &amp; uniquely light</td>\r\n			<td>\r\n			<ul style="list-style-type:square;">\r\n				<li>penetrates skin easily allowing skin to drink up all the benefits without greasy after feel</li>\r\n			</ul>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Fresh &amp; sweet smelling coconut essence</td>\r\n			<td>\r\n			<ul style="list-style-type:square;">\r\n				<li>natural aroma</li>\r\n			</ul>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Long shelf life of more than 3 years</td>\r\n			<td>\r\n			<ul style="list-style-type:square;">\r\n				<li>stays fresh without the use of preservatives and additives</li>\r\n			</ul>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<h5>3 Seasons</h5>\r\n\r\n<p>Just like water, organic coconut virgin oil being unadulterated changes its state with drop in temperature. Warm at heart, adara&trade; crystallises to a dazzling white as temperature drops below 23&deg;C. All it takes is some warmth to bring adara back to pristine clear oil. Simply submerge bottle into warm water or place it in room temperature above 23&deg;C.</p>\r\n\r\n<p>A legendary secret unveiled for modern age application. A fusion of time to see the adara in you.</p>\r\n', 1, 1, 1, 'Ismo Broto', '2015-12-23 11:22:27', '', '0000-00-00 00:00:00'),
(6, 2, 2, 'Coconut Cream', '<p>Colour &amp; Appearance</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>Creamy white</li>\r\n</ul>\r\n\r\n<p>Taste</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>Sweet and natural</li>\r\n	<li>Free from foreign odour</li>\r\n</ul>\r\n\r\n<p>Type : Industrial Packs</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>17% fat content, non -GM</li>\r\n	<li>17% fat content, without additive</li>\r\n	<li>17% fat content, regular</li>\r\n	<li>24% fat content, non GM</li>\r\n	<li>24% fat content, without additive</li>\r\n	<li>24% fat content, regular</li>\r\n</ul>\r\n\r\n<p>Viscosity</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>Pourable less than 2000cps at 25-30&deg;C</li>\r\n</ul>\r\n\r\n<p>Packaging : Intasept aseptic bag</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>5kg and 20kg in carton and 200kg bag in 55 US gallon drums</li>\r\n</ul>\r\n\r\n<p>Storage</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>Store under cool and dry conditons</li>\r\n	<li>Do not freeze</li>\r\n	<li>Do not store below 4&deg;C</li>\r\n</ul>\r\n\r\n<p>Shelf Life</p>\r\n\r\n<ul style="list-style-type:square;">\r\n	<li>15 months under good storage condition</li>\r\n</ul>\r\n', 1, 1, 1, 'Ismo Broto', '2015-12-31 13:54:56', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_product_category`
--

CREATE TABLE IF NOT EXISTS `tbl_product_category` (
  `id_category_product` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `name_category_product` varchar(30) NOT NULL,
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_product_category`
--

INSERT INTO `tbl_product_category` (`id_category_product`, `id_type`, `name_category_product`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 1, 'Food', 'Ismo Broto', '2015-12-22 13:56:08', 'Ismo Broto', '2015-12-22 13:58:32'),
(2, 2, 'Food', 'Ismo Broto', '2015-12-22 11:25:09', '', '0000-00-00 00:00:00'),
(3, 1, 'Beverage', 'Ismo Broto', '2015-12-22 13:59:30', '', '0000-00-00 00:00:00'),
(4, 2, 'Beverage', 'Ismo Broto', '2015-12-22 13:59:41', 'Ismo Broto', '2015-12-22 14:10:27'),
(5, 1, 'Organic', 'Ismo Broto', '2015-12-22 15:43:07', '', '0000-00-00 00:00:00'),
(6, 1, 'Personal', 'Ismo Broto', '2015-12-23 11:23:19', 'Ismo Broto', '2015-12-26 08:13:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_product_type`
--

CREATE TABLE IF NOT EXISTS `tbl_product_type` (
  `id_type` int(11) NOT NULL,
  `name_type` varchar(50) NOT NULL,
  `descrept_type` text NOT NULL,
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_product_type`
--

INSERT INTO `tbl_product_type` (`id_type`, `name_type`, `descrept_type`, `created_by`, `created_date`) VALUES
(1, 'Consumer Product', 'Consumer Product', 'Ismo', '2015-12-22 00:00:00'),
(2, 'Industrial Product', 'Industrial Product', 'Ismo', '2015-12-22 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_profile_head`
--

CREATE TABLE IF NOT EXISTS `tbl_profile_head` (
  `id_head_profile` int(11) NOT NULL,
  `head_abbr` varchar(10) NOT NULL,
  `head_descript` varchar(100) NOT NULL,
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_profile_head`
--

INSERT INTO `tbl_profile_head` (`id_head_profile`, `head_abbr`, `head_descript`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 'sambu', 'Sambu Group', 'Ismo Broto', '2015-12-17 02:02:03', 'Ismo Broto', '2015-12-26 08:30:32'),
(2, 'psg', 'Pulau Sambu Guntung', 'Ismo Broto', '2015-12-17 14:45:53', 'Ismo Broto', '2015-12-21 08:46:30'),
(4, 'pske', 'Pulau Sambu Kuala Enok', 'Ismo Broto', '2015-12-22 08:52:17', '', '0000-00-00 00:00:00'),
(5, 'rsup', 'Riau Sakti United Plantations', 'Ismo Broto', '2015-12-22 09:49:45', 'Ismo Broto', '2016-01-11 15:43:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_profile_post`
--

CREATE TABLE IF NOT EXISTS `tbl_profile_post` (
  `kode_profile` varchar(6) NOT NULL,
  `id_head` int(11) NOT NULL,
  `title_profile` varchar(150) NOT NULL,
  `post_profile` text NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `layout_content` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_profile_post`
--

INSERT INTO `tbl_profile_post` (`kode_profile`, `id_head`, `title_profile`, `post_profile`, `publish`, `layout_content`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
('77VjI', 1, 'Ethical Trading', '<blockquote>\r\n<p><em><span style="color:#008000;">...to promote a community of harmony<br />\r\n...to strike a delicate balance of quality business and social wellness</span></em></p>\r\n\r\n<p style="text-align: right;"><em><small>Sambu Group, The Coconut Family on Riau Province of East Sumatra</small></em></p>\r\n</blockquote>\r\n\r\n<p><img alt="" src="/SambuPage/assets/upload/images/15-12-31(8ib7nz.png" style="float: right; width: 145px; height: 256px;" />Once a barren land with scarce business activities, now a thriving vibrant community&hellip; the transition from rural area to today&rsquo;s community of harmony with gainful employment is a conscientious effort towards contributing to the society, a core part of our corporate culture.</p>\r\n\r\n<p>We believe in investment and employees are our best asset, only when employees welfare are well taken care of can a company grow in pride. As a socially responsible company, we strive to meet employees and their families needs so as to achieve happiness in our own little ways.</p>\r\n\r\n<p>Implementation is key and we continuously develop three core sectors that give birth to a community of harmonious living</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h5>Gainful Employment</h5>\r\n\r\n<p>All three manufacturing sites continuously create employment for the locals which provide them with stable income to fulfil their basic needs including that of their families.</p>\r\n\r\n<p>A healthy and safe working environment is created for each employee.</p>\r\n\r\n<ul>\r\n	<li>PT Pulau Sambu Kuala Enok, the coconut oil plant, and PT Pulau Sambu Guntung, the desiccated coconut and coconut milk plant, are accredited to Occupational Health and Safety Standard 18001</li>\r\n	<li>Safety trainings are given to new and existing employees periodically</li>\r\n	<li>No child labour is allowed on site</li>\r\n	<li>Every shift of worker is provided one complimentary meal</li>\r\n</ul>\r\n\r\n<p>Fair remuneration</p>\r\n\r\n<ul>\r\n	<li>Minimum wage is always set above both industrial and government standards and increments are followed accordingly</li>\r\n	<li>Shift system is employed to ensure employees working hours are in line with industrial standards</li>\r\n	<li>Overtime is only required during peak periods and on voluntary basis only</li>\r\n</ul>\r\n\r\n<p>PT Pulau Sambu Kuala Enok and PT Pulau Sambu Guntung are accredited to environmental standard ISO14001. All practices are environmentally friendly in accordance to the protocol.</p>\r\n\r\n<p>Embraces the Principle of Total Quality Management and continuously upgrade skills of the workforce where applicable.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h5>Social Wellness</h5>\r\n\r\n<p>All employees and their families, a total community of 50,000 on Riau Province, are provided with housing, educational and recreational facilities all at heavily subsidised rates, amounts that are affordable taking into considerations of their income. This is implemented to prevent wellness programme from being abused and at the same time ensuring adequate living standards for all.</p>\r\n\r\n<p><img alt="" src="/SambuPage/assets/upload/images/15-12-31(5uwhhu.png" style="float: left; width: 240px; height: 173px;" />Housing allocations</p>\r\n\r\n<p>Polyclinics facilities</p>\r\n\r\n<p>Religious centres &ndash; mosques, temples and churches are built with respect to religious sensitivities.</p>\r\n\r\n<p>Educational facilities</p>\r\n\r\n<ul>\r\n	<li>Schools from kindergarten to secondary levels are built to provide basic education for children and equip them with social skills</li>\r\n	<li>All children are ferried to and from school at no charges, via the group&rsquo;s specially constructed canal system</li>\r\n	<li>Educational system and curriculum are constantly upgraded to keep up with societal changes</li>\r\n</ul>\r\n\r\n<p>Playgrounds and communal areas are built to foster social bonding &amp; enhance community spirit.</p>\r\n\r\n<p><img alt="" src="/SambuPage/assets/upload/images/15-12-31(m6rngb.png" style="float: right; width: 197px; height: 120px;" />Marketplaces are built to open up different avenues for locals to earn their keeps. Stalls are leased out for sales of daily necessities, and in turn create little bustling business areas to keep the community vibrant.</p>\r\n\r\n<p>These facilities are also open to non-employees, a move towards harmonious living for all.</p>\r\n\r\n<p>In the pipeline, a 3 storey separate office building on Guntung site is now being converted into a hospital and due for completion by 2006, operational by 2007/2008.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h5>Basic Provisions</h5>\r\n\r\n<p>Water and electricity are supplied to employees and families of all three manufacturing sites at subsidised rate.</p>\r\n\r\n<p>At Sambu Group, we believe in fair trade.</p>\r\n\r\n<blockquote>\r\n<p><em><span style="color:#008000;">Love makes the world go round, Ethics make Sambu Group grow well! </span></em></p>\r\n</blockquote>\r\n', 1, 1, 'Ismo Broto', '2015-12-31 15:23:01', 'Ismo Broto', '2015-12-31 15:25:24'),
('aBoQK', 2, 'Pulau Sambu Guntung Profile', '<p>PT Pulau Sambu Guntung (PSG) was founded in 1983 in Guntung in Riau Province. From the beginning, PSG&#39;s main products have been coconut cream and desiccated coconut.</p>\r\n\r\n<p>PSG is a supplier of desiccated coconut to well known confectioners and chocolate industries in Europe, North America, Australia, Middle East and China. Its coconut cream, under the Kara brand name, is now popular in Asian, Australian and European markets. With the ever increasing popularity of Asian dishes that have coconut cream as an ingredient, the market for coconut cream is bound to expand worldwide.</p>\r\n\r\n<p>Prior to production, the best quality coconuts are screened and selected to produce the highest quality coconut cream and desiccated coconut using high technology equipment. One of the keys to the high quality of PSG&#39;s desiccated coconut is its Proctor and Schwartz&#39;s three stage dryer which was built specifically for the company&#39;s application. In addition, the Alfal-Laval production line, which has been painstakingly perfected over the years, now produces coconut cream of a quality second to none.</p>\r\n\r\n<p>Encouraged by the success of Kara cream, PSG expanded its production to produce nata de coco, coconut virgin oil for pharmaceutical industry, charcoal from coconut shell, coconut water and drinking water under the brand name of Kara Ases. In 2001, PSG started commercial production of spray dried Coconut Milk Powder.</p>\r\n\r\n<p>PSG has 4000 employees, all fully committed to the implementation of Hazard Analysis Critical Control Point (HACCP) standardization, a stringent hygiene standard which requires continuous monitoring and inspection of the various stages of the production process. In November 2000, PSG was awarded both ISO9002 and HACCP certification by SGS Singapore.</p>\r\n\r\n<p>Like PSK, PSG is also a fully self sufficient and self supporting complex. The complex has satellite communications facilities and its own power generator that provides electricity for the entire complex as well as for domestic use by the employees. Its port built in 1989 is equipped with two 40ft heavy container cranes that can load large ocean going vessels efficiently.</p>\r\n\r\n<p>Another distinct advantage of PSG is that it is strategically located near Singapore. All cargoes are exported via Singapore&#39;s efficient and world class seaport.</p>\r\n', 1, 3, 'Ismo Broto', '2015-12-21 15:29:19', 'Ismo Broto', '2016-01-09 08:36:27'),
('IaZBs', 1, 'Corporate Philosophy', '<p>We believe in being First.</p>\r\n\r\n<p>We will conduct our businesses with Honesty and Integrity to achieve the best Quality Products &amp; Services.</p>\r\n\r\n<p>We trust our People to do their best and to Continuously Progress in Ideas and Processes to achieve the highest Customer Satisfaction.</p>\r\n', 1, 1, 'Ismo Broto', '2015-12-18 10:03:17', 'Ismo Broto', '2015-12-31 14:17:19'),
('P52Ht', 1, 'Our History', '<p>The value of coconuts is unfathomable. Few understand the holistic chain of attributes it can provide, right from the outermost layer of husk to the innermost core of white meat. The list of produce is exponential to its parts.</p>\r\n\r\n<p>Coconut. Enormous benefits.</p>\r\n\r\n<p>Husk, shell, parings, white meat, copra, water&hellip;each component has its varied uses from food to non-food items, from industrial to household purposes. The mattresses we sleep on, ropes we use , and seats we covet are sometimes made with coconut fiber.</p>\r\n\r\n<p>Other parts of coconuts are made into edibles and ingredients for confectioners, chefs and homemakers the world over, in their preparation for pastries, chocolates, desserts, authentic Asian dishes, the list goes on and on...</p>\r\n\r\n<p>Coconut has demonstrated its indispensable role in our daily lives.</p>\r\n\r\n<p>No parts of a coconut are put to waste. Its uses are multiple and its values are wholesome. With this insight to the life cycle of a coconut, we know there is no hint of exaggeration when coconut tree was acclaimed as The Tree of Life.</p>\r\n\r\n<p>To keep The Tree of Life as a living legacy, PT. Pulau Sambu was established to maximize the value of coconuts and pass on the goodness to consumers worldwide. Under the visionary and enterprising leadership of the founder, Mr. Tay Juhana, it has from the very beginning been positioned as a coconut specialist.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h5>The legacy of The Sambu Group begins...</h5>\r\n\r\n<p>I<img alt="" src="/SambuPage/assets/upload/images/15-12-31(7cz3pw.png" style="float: right; width: 219px; height: 376px;" />t started humbly as a coconut oil processing plant, PT Pulau Sambu Kuala Enok, in the Riau province of Sumatra, Indonesia in 1967, focusing on producing crude coconut oil, cooking oil and copra expeller for the export market. Products are ensured of internationally accepted standards.</p>\r\n\r\n<p>In 1983, a second processing plant was founded. PT Pulau Sambu Guntung concentrated on manufacturing desiccated coconut, coconut cream and made known its house brand, Kara, to nationwide, particularly Asian, Australian, the United States and European markets.</p>\r\n\r\n<p>In 1993, with superior raw materials for quality production coupled with rising market demands, a third production and processing plant, PT Riau Sakti United Plantations (RSUP), was set up. It handles desiccated coconut and coconut cream production for export markets.</p>\r\n\r\n<p>In 1995, a pineapple production plant was set up in RSUP to produce canned pineapples and subsequently pineapple juice concentrate in 1999.</p>\r\n\r\n<p>From the 60s till the 90s, Mr. Tay Juhana&#39;s effort expanded from production and processing to crop intensification. And the synergy of dedication and innovation lives on</p>\r\n\r\n<p>These were all made possible by sheer determination and absolute focus on quality.</p>\r\n\r\n<p><img alt="" src="/SambuPage/assets/upload/images/15-12-31(fe7nkk.png" style="float: left; width: 300px; height: 266px; padding-right: 25px;" />The Sambu Group today has emerged as the single largest integrated coconut industry in the world, showcasing 3 factories. PT Pulau Sambu Kuala Enok, PT Pulau Sambu Guntung and PT Riau Sakti United Plantations, all internationally recognized as leaders in the coconut and pineapple industries. In addition, the Group&#39;s operations have philanthropically established social communities to provide for all workers&#39; basic needs including lodging, educational, medical and recreational facilities. What could have been a barren land with scarce business activities has now thrived and evolved from a rural area to a vibrant community.</p>\r\n\r\n<p>Sambu Group prides ourselves as producers who are committed to delivering the best products catering to the world market.</p>\r\n', 1, 1, 'Ismo Broto', '2015-12-31 14:33:22', 'Ismo Broto', '2015-12-31 14:38:59'),
('Q4X5T', 4, 'Pulau Sambu Kuala Enok Profile', '<p>PT Pulau Sambu Kuala Enok (PSKE) was founded in 1967 with a work force of 30 on the tropical island of Nyiur, in the Indragiri district of Riau province. In the early stages of its operation, it relied solely on traditional methods to produce crude coconut oil for the local market.</p>\r\n\r\n<p>Realizing the importance of a continuous supply of fresh and quality coconuts, the company has established a close and mutually beneficial relationship with the coconut farmers in its surrounding regions. This has advertently created a stable avenue for coconut farmers to earn their keeps.</p>\r\n\r\n<p>The company began to invest in modern and high capacity machinery from Germany and Sweden in the early 1970s. In 1979, the company built its own storage facilities and installed a 400 tons per hour blow pump loading system for coconut oil. The handling of raw material and the loading of copra extraction pellets are efficiently done using an integrated system of conveyor belts.</p>\r\n\r\n<p>30 over years after its founding, PSKE is now a self contained and self sufficient production complex. It has its own power plant with steam generators heated by coconut shells, modem telecommunications facilities, jetties that allow vessels of up to 30000 dwt to berth and load, a multi purpose training center, housing for over 2000 employees and more than a hundred boats to transport raw copra and coconuts.</p>\r\n\r\n<p>Today PSK produces primarily crude coconut oil, cooking oil and copra extraction pellets. These products are exported to Asian countries, Europe, USA and Australia.</p>\r\n\r\n<p>PSKE is the nucleus of the Sambu Group. It has given birth to more than a dozen other companies. Since its inception, PSKE has striven to be a global player in the coconut industry.</p>\r\n\r\n<p>The company firmly believes in constantly upgrading the skills of its workforce so that it can compete globally. In the 1990s, it has adopted and practised the Principle of Total Quality Management (TQM).</p>\r\n\r\n<p>On 23rd September 1995, for its effective implementation of TQM at all levels, PSK was awarded the ISO9002 certificate by the Singapore Institute of Standards and Industrial Research (SISIR) which is now referred to as Productivity &amp; Standards Board (PSB) Corp of Singapore.</p>\r\n\r\n<p>In the year 2000/2001, PSK went on to achieve ISO14001 (Environmental Management System), OHSAS 18001 (Occupational Health &amp; Safety), ISO 17025 (Laboratory Standard) and GMP / HACCP.</p>\r\n\r\n<p>PSK strictly implements its quality improvement program in the belief that only by maintaining world class quality standards of production and management can a company survive in tomorrow&#39;s competitive global business environment.</p>\r\n', 1, 2, 'Ismo Broto', '2015-12-22 08:51:20', 'Ismo Broto', '2016-01-09 08:17:29'),
('RVqqu', 5, 'Riau Sakti United Plantations Profile', '<p>adsadsadsa</p>\r\n', 1, 1, 'Ismo Broto', '2015-12-22 09:54:14', 'Ismo Broto', '2016-01-11 15:43:10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_setting`
--

CREATE TABLE IF NOT EXISTS `tbl_setting` (
  `key_setting` int(11) NOT NULL,
  `name_company` varchar(50) DEFAULT NULL,
  `display_company` varchar(50) DEFAULT NULL,
  `address` text,
  `work_time` text,
  `longitude_map` varchar(20) DEFAULT NULL,
  `latitude_map` varchar(20) DEFAULT NULL,
  `phone1` varchar(20) DEFAULT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `google_plus` varchar(105) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `updated_by` varchar(35) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_setting`
--

INSERT INTO `tbl_setting` (`key_setting`, `name_company`, `display_company`, `address`, `work_time`, `longitude_map`, `latitude_map`, `phone1`, `phone2`, `fax`, `facebook`, `twitter`, `instagram`, `google_plus`, `email`, `updated_by`, `updated_date`) VALUES
(1, 'PT. Sambu Group', 'Pulau Sambu Singapure PTE LTD', '<p>19 Tanglin Road <br /> Unit #11-01/12 <br /> Tanglin Shopping Centre, <br /> Singapure - 247909</p>', '<p>08:00 AM - 05.00 PM<br /> Monday to Saturday</p>', '1.3066451', '103.8270222', '+65(67) 34 7138_', '', '+65(67) 34 8601_', 'http://facebook.com/Pulau-Sambu-Singapure-PTE-LTD-923971627699436', 'https://twitter.com/PulauSambuPTE', '', 'http://plus.google.com/u/1/116020015100385393622', 'info@sambu.com.sg', 'Ismo Broto', '2016-01-12 16:14:27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_group_user`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_group_user` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(30) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_group_user`
--

INSERT INTO `tbl_utl_group_user` (`group_id`, `group_name`, `active`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 'Administrator', 1, 'Ismo Broto', '2015-12-07 10:00:00', '', '0000-00-00 00:00:00'),
(2, 'Super Administrator', 1, 'Ismo Broto', '2016-01-18 10:10:06', 'Ismo Broto', '2016-01-18 10:50:16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_menu_access`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_menu_access` (
  `group_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_menu_access`
--

INSERT INTO `tbl_utl_menu_access` (`group_id`, `menu_id`) VALUES
(2, 100),
(2, 110),
(2, 120),
(2, 300),
(2, 310),
(2, 320),
(2, 330),
(2, 400),
(2, 410),
(2, 420),
(2, 430),
(2, 500),
(2, 510),
(2, 520),
(2, 530),
(2, 700),
(2, 710),
(2, 720),
(2, 730),
(2, 800),
(2, 810),
(2, 820),
(2, 830),
(2, 900),
(2, 910),
(2, 920),
(2, 930),
(2, 999),
(1, 100),
(1, 110),
(1, 120),
(1, 300),
(1, 310),
(1, 320),
(1, 330),
(1, 400),
(1, 410),
(1, 420),
(1, 430),
(1, 500),
(1, 510),
(1, 520),
(1, 530),
(1, 800),
(1, 810),
(1, 820),
(1, 830),
(1, 900),
(1, 910),
(1, 920),
(1, 930),
(1, 999);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_menu_lv1`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_menu_lv1` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_label` varchar(100) NOT NULL,
  `menu_icon` varchar(100) NOT NULL,
  `menu_link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_menu_lv1`
--

INSERT INTO `tbl_utl_menu_lv1` (`menu_id`, `menu_name`, `menu_label`, `menu_icon`, `menu_link`) VALUES
(100, 'comment', 'Comment', '<i class="entypo-chat"></i>', '#'),
(300, 'BlogNews', 'Blog News', '<i class="entypo-docs"></i>', '#'),
(400, 'setupProduct', 'Setup Product', '<i class="entypo-box"></i>', '#'),
(500, 'setupVacancy', 'Setup Vacancy', '<i class="entypo-user-add"></i>', '#'),
(700, 'setupUtility', 'Utility', '<i class="entypo-users"></i>', '#'),
(800, 'SetupProfile', 'Page Profile', '<i class="entypo-vcard"></i>', '#'),
(900, 'setting', 'Setting', '<i class="entypo-cog"></i>', '#'),
(999, 'Logout', 'Sign Out', '<i class="entypo-lock"></i>', 'back/login/logout');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_menu_lv2`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_menu_lv2` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_label` varchar(100) NOT NULL,
  `menu_icon` varchar(100) NOT NULL,
  `menu_link` varchar(100) NOT NULL,
  `menu_header` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_menu_lv2`
--

INSERT INTO `tbl_utl_menu_lv2` (`menu_id`, `menu_name`, `menu_label`, `menu_icon`, `menu_link`, `menu_header`) VALUES
(110, 'All Comment', 'All Comment', '<i class="fa fa-caret-right"></i>', 'back/comment', 100),
(120, 'trashComment', 'Trash', '<i class="fa fa-caret-right"></i>', 'back/comment/commentTrashed', 100),
(310, 'setCategory', 'Category', '<i class="fa fa-caret-right"></i>', 'back/post/category', 300),
(320, 'allPost', 'All Post', '<i class="fa fa-caret-right"></i>', 'back/post/allPost', 300),
(330, 'createPost', 'New Post', '<i class="fa fa-caret-right"></i>', 'back/post/newPost', 300),
(410, 'setCategory', 'Category Product', '<i class="fa fa-caret-right"></i>', 'back/setupProductCategory', 400),
(420, 'allProduct', 'All Product', '<i class="fa fa-caret-right"></i>', 'back/setupProduct/allProduct', 400),
(430, 'addProduct', 'Add Product', '<i class="fa fa-caret-right"></i>', 'back/setupProduct/index', 400),
(510, 'addCategory', 'Category', '<i class="fa fa-caret-right"></i>', 'back/setupVacancy/categoryVacancy', 500),
(520, 'allVacancy', 'All Vacancy', '<i class="fa fa-caret-right"></i>', 'back/setupVacancy/allVacancy', 500),
(530, 'addVacancy', 'Add Vacancy', '<i class="fa fa-caret-right"></i>', 'back/setupVacancy/addVacancy', 500),
(710, 'groupuser', 'Group User', '<i class="fa fa-caret-right"></i>', 'back/groupuser', 700),
(720, 'userLogin', 'Users', '<i class="fa fa-caret-right"></i>', 'back/users', 700),
(730, 'menuAkses', 'Accsess Menu', '<i class="fa fa-caret-right"></i>', 'back/accessMenu', 700),
(810, 'setupHeadProfile', 'Head Profile', '<i class="fa fa-caret-right"></i>', 'back/setupProfile/indexHeadProfile', 800),
(820, 'viewAllProfil', 'All Profile', '<i class="fa fa-caret-right"></i>', 'back/SetupProfile', 800),
(830, 'setupPostProfile', ' New Profile Content', '<i class="fa fa-caret-right"></i>', 'back/setupProfile/indexProfileContent', 800),
(910, 'settingPage', 'Page', '<i class="fa fa-caret-right"></i>', 'back/setupPage', 900),
(920, 'Profile', 'Profile', '<i class="fa fa-caret-right"></i>', 'back/setting', 900),
(930, 'widget', 'Widget', '<i class="fa fa-caret-right"></i>', 'back/setupWidget', 900);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_menu_lv3`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_menu_lv3` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_label` varchar(100) NOT NULL,
  `menu_icon` varchar(100) NOT NULL,
  `menu_link` varchar(100) NOT NULL,
  `menu_header` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_menu_lv3`
--

INSERT INTO `tbl_utl_menu_lv3` (`menu_id`, `menu_name`, `menu_label`, `menu_icon`, `menu_link`, `menu_header`) VALUES
(121, 'Philosophy', 'Corporate Philosophy', '', 'Philosophy', 210),
(122, 'History', 'History', '', 'History', 210),
(123, 'EthicalTrading', 'Ethical Trading', '', 'EthicalTrading', 210),
(124, 'menu124', 'Menu 124', '', '#', 130);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_user` (
  `username` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nickname` varchar(35) NOT NULL,
  `long_name` varchar(55) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL,
  `avatar` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_user`
--

INSERT INTO `tbl_utl_user` (`username`, `password`, `nickname`, `long_name`, `group_id`, `active`, `created_by`, `created_date`, `updated_by`, `updated_date`, `avatar`) VALUES
('harry', 'e10adc3949ba59abbe56e057f20f883e', 'Harry', NULL, 1, 1, 'Ismo Broto', '2015-12-07 10:00:00', '', '0000-00-00 00:00:00', 0),
('ismo_broto', 'e10adc3949ba59abbe56e057f20f883e', 'Ismo', 'Ismo Broto', 2, 1, 'Ismo Broto', '2015-12-07 10:00:00', 'Ismo', '2016-01-25 15:13:48', 0),
('satrio', 'e10adc3949ba59abbe56e057f20f883e', 'Satrio', NULL, 1, 1, 'Ismo Broto', '2015-12-07 10:00:00', '', '0000-00-00 00:00:00', 0),
('syafrudin', 'e10adc3949ba59abbe56e057f20f883e', 'Syafrudin', NULL, 1, 1, 'Ismo Broto', '2015-12-07 10:00:00', '', '0000-00-00 00:00:00', 0),
('tct', '0c9d3e16d5401c568039dcb6ee74358b', 'Ciatung', 'Tay Ciatung', 1, 1, 'Ismo Broto', '2015-12-07 10:00:00', '', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_utl_user_log`
--

CREATE TABLE IF NOT EXISTS `tbl_utl_user_log` (
  `id_log` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `log_time` datetime NOT NULL,
  `hostname` varchar(100) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `device` varchar(100) NOT NULL,
  `browser` varchar(100) NOT NULL,
  `platform` varchar(100) NOT NULL,
  `user_agent` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_utl_user_log`
--

INSERT INTO `tbl_utl_user_log` (`id_log`, `username`, `log_time`, `hostname`, `ip_address`, `device`, `browser`, `platform`, `user_agent`) VALUES
(1, 'ISMO_BROTO', '2016-01-09 00:54:07', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(2, 'ISMO_BROTO', '2016-01-10 20:56:49', 'k555.CWP2.COM', '::1', 'PC', 'Firefox 43.0', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0'),
(3, 'ISMO_BROTO', '2016-01-11 17:44:29', 'k555.CWP2.COM', '::1', 'PC', 'Firefox 43.0', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0'),
(4, 'ISMO_BROTO', '2016-01-12 00:20:16', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(5, 'ISMO_BROTO', '2016-01-12 17:15:43', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(6, 'ISMO_BROTO', '2016-01-13 00:04:44', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(7, 'ISMO_BROTO', '2016-01-15 19:38:07', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(8, 'ISMO_BROTO', '2016-01-18 08:08:12', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(9, 'ISMO_BROTO', '2016-01-18 16:33:31', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(10, 'ISMO_BROTO', '2016-01-18 16:35:01', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'),
(11, 'ISMO_BROTO', '2016-01-19 09:06:30', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(12, 'ISMO_BROTO', '2016-01-20 08:20:50', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(13, 'ISMO_BROTO', '2016-01-23 08:43:24', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(14, 'ISMO_BROTO', '2016-01-23 10:55:34', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(15, 'ISMO_BROTO', '2016-01-24 17:14:08', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(16, 'ISMO_BROTO', '2016-01-25 08:14:42', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(17, 'ISMO_BROTO', '2016-01-25 13:28:52', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(18, 'ISMO_BROTO', '2016-01-25 15:09:20', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36'),
(19, 'ISMO_BROTO', '2016-02-24 09:11:50', 'k555.CWP2.COM', '::1', 'PC', 'Chrome 48.0.2564.116', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_vacancy_category`
--

CREATE TABLE IF NOT EXISTS `tbl_vacancy_category` (
  `id_category` int(11) NOT NULL,
  `name_category` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `count_vacancy` int(11) NOT NULL,
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_vacancy_category`
--

INSERT INTO `tbl_vacancy_category` (`id_category`, `name_category`, `active`, `count_vacancy`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 'Information Technology', 1, 1, 'Ismo Broto', '2016-01-04 18:26:20', '', '0000-00-00 00:00:00'),
(2, 'Building Management', 1, 0, 'Ismo Broto', '2016-01-04 18:51:32', 'Ismo Broto', '2016-01-04 18:51:54'),
(4, 'General Office', 1, 1, 'Ismo Broto', '2016-01-04 19:16:06', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_vacancy_jobs`
--

CREATE TABLE IF NOT EXISTS `tbl_vacancy_jobs` (
  `id_vacancy` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `title_jobs` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `closed_date` date NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `thumbnail` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_vacancy_jobs`
--

INSERT INTO `tbl_vacancy_jobs` (`id_vacancy`, `id_category`, `title_jobs`, `description`, `closed_date`, `publish`, `thumbnail`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 4, 'Internal Auditor', '<p><strong>Requirements :</strong></p>\r\n\r\n<ul>\r\n	<li>Male / Female (Single), Minimum Bachelor / GPA min. 3:00</li>\r\n	<li>Leading universities min. accreditation B</li>\r\n	<li>Age Minimum 23 Year - Maximum 30 Years</li>\r\n	<li>Understanding of ISO, Food Industry, SMK3, OHSAS 18001, FSSC 22000, Document Control.</li>\r\n	<li>Can speak English</li>\r\n	<li>Needs 10 people</li>\r\n	<li>Solution Oriented an added value</li>\r\n	<li>Willing to be placed in Sungai Guntung Kec. Kateman &ndash; Indragiri Hilir - RIAU</li>\r\n</ul>\r\n\r\n<p style="text-align: center;"><span style="color:#FF0000;">SEND YOUR COMPLETE APPLICATION TO:<br />\r\nPT.PULAU SAMBU GUNTUNG<br />\r\nSEI GUNTUNG, KEC.KATEMAN, KAB.INHIL RIAU 29255</span></p>\r\n', '2016-01-30', 1, 0, 'Ismo Broto', '2016-01-04 19:16:36', 'Ismo Broto', '2016-01-06 08:44:19'),
(2, 1, 'Web Programmer', '<ul>\r\n	<li>Candidate must possess at least a Bachelor&#39;s Degree, any field.</li>\r\n	<li>At least 2 year(s) of working experience in the related field is required for this position.</li>\r\n	<li>Experienced with PHP Framework.</li>\r\n	<li>Experienced with jQuery.</li>\r\n	<li>Experienced with AJAX.</li>\r\n	<li>Experienced with CSS.</li>\r\n	<li>Experienced with HTML5.</li>\r\n</ul>\r\n', '2016-02-01', 1, 1, 'Ismo Broto', '2016-01-04 20:42:11', 'Ismo Broto', '2016-01-06 08:50:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_visitor`
--

CREATE TABLE IF NOT EXISTS `tbl_visitor` (
  `date_visit` datetime NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `hostname` varchar(100) NOT NULL,
  `device` varchar(100) NOT NULL,
  `browser` varchar(100) NOT NULL,
  `platform` varchar(100) NOT NULL,
  `user_agent` varchar(250) NOT NULL,
  `on_page` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = Front Page ; 1 = Back Page'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_visitor`
--

INSERT INTO `tbl_visitor` (`date_visit`, `ip_address`, `hostname`, `device`, `browser`, `platform`, `user_agent`, `on_page`) VALUES
('2016-01-16 00:17:26', '::1', 'k555', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 0),
('2016-01-16 00:19:14', '192.168.12.136', 'k555', 'AndroidOS Safari UCBrowser ', 'Safari 534.30', 'Android', 'Mozilla/5.0 (Linux; U; Android 5.1; en-US; m2 note Build/LMY47D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.8.0.718 U3/0.8.0 Mobile Safari/534.30', 0),
('2016-01-18 08:08:51', '::1', 'k555', 'PC', 'Chrome 47.0.2526.106', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 0),
('2016-01-19 09:12:33', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-19 09:16:14', '::1', 'k555', 'PC', 'Firefox 43.0', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', 1),
('2016-01-20 08:20:15', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-20 14:58:27', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 1),
('2016-01-23 08:34:48', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-23 10:54:49', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 1),
('2016-01-25 08:12:22', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-25 13:28:15', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 1),
('2016-01-25 16:49:59', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-26 13:32:45', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-27 09:13:54', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-01-27 09:14:02', '::1', 'k555', 'PC', 'Chrome 47.0.2526.111', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36', 0),
('2016-02-02 09:21:42', '::1', 'k555', 'PC', 'Chrome 48.0.2564.97', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36', 0),
('2016-02-11 14:49:01', '::1', 'k555', 'PC', 'Chrome 48.0.2564.103', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.103 Safari/537.36', 0),
('2016-02-24 09:11:27', '::1', 'k555', 'PC', 'Chrome 48.0.2564.116', 'Windows 7', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_widget`
--

CREATE TABLE IF NOT EXISTS `tbl_widget` (
  `code_widget` varchar(6) NOT NULL,
  `type_widget` tinyint(1) NOT NULL COMMENT '1=Slider;2=Quotes;3=TagLine',
  `title_widget` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `icon_tag_line` varchar(30) NOT NULL,
  `thumb_potition` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1: right; 0:left',
  `thumb_slider` tinyint(1) NOT NULL DEFAULT '0',
  `thumb_product_tile` tinyint(1) NOT NULL DEFAULT '0',
  `quote_by` varchar(60) NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(35) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_widget`
--

INSERT INTO `tbl_widget` (`code_widget`, `type_widget`, `title_widget`, `description`, `icon_tag_line`, `thumb_potition`, `thumb_slider`, `thumb_product_tile`, `quote_by`, `publish`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
('03FEQ', 3, 'Renewal', '<p>We trust our People to do their best and to Continuously Progress in Ideas and Processes to achieve the highest Customer Satisfaction.</p>', 'entypo-arrows-ccw', 1, 0, 0, '', 1, 'Ismo Broto', '2016-01-09 10:08:51', '', '0000-00-00 00:00:00'),
('4KUni', 4, 'Kara Creame', '', '', 1, 0, 1, '', 1, 'Ismo Broto', '2016-01-09 13:22:48', 'Ismo Broto', '2016-01-09 13:42:55'),
('4nFjD', 3, 'COMMITMENT', '<p><span style="color: #999999; font-family: ''Noto Sans'', ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 13px; line-height: 18.5714px;">We will conduct our businesses with Honesty and Integrity to achieve the best Quality Products &amp; Services.</span></p>', 'entypo-users', 1, 0, 0, '', 1, 'Ismo Broto', '2016-01-09 16:03:25', '', '0000-00-00 00:00:00'),
('6w9Q1', 4, 'Tropi Colada', '', '', 1, 0, 1, '', 1, 'Ismo Broto', '2016-01-16 11:12:35', '', '0000-00-00 00:00:00'),
('73cGF', 2, 'Tukul', '<p>dsadsad<br />asdad&nbsp;</p>', '', 1, 0, 0, 'Tukul', 1, 'Ismo Broto', '2016-01-09 16:28:21', 'Ismo Broto', '2016-01-09 16:38:05'),
('ANCqh', 4, 'Fruitland', '', '', 1, 0, 1, '', 0, 'Ismo Broto', '2016-01-16 11:14:01', 'Ismo Broto', '2016-01-16 11:42:18'),
('fKESf', 1, 'PT Pulau Sambu Guntung', '<h2 style="opacity: 1; top: 0px;"><small style="opacity: 1; top: 0px;">PT Pulau Sambu Guntung (PSG)</small> Member of Sambu Group</h2>\r\n<p style="opacity: 0.7; top: 0px;">PT Pulau Sambu Guntung (PSG) was founded in 1983 in Guntung in Riau Province. From the beginning, PSG''s main products have been coconut cream and desiccated coconut.</p>', '', 1, 1, 0, '', 1, 'Ismo Broto', '2016-01-04 15:45:10', 'Ismo Broto', '2016-01-09 09:04:42'),
('KBmtO', 1, 'PT Pulau Sambu Kuala Enok', '<h2 style="opacity: 1; top: 0px;"><small style="opacity: 1; top: 0px;">PT Pulau Sambu Kuala Enok(PSKE)</small> Member of Sambu Group</h2>\r\n<p style="opacity: 0.7; top: 0px;">PT Pulau Sambu Guntung (PSG) was founded in 1983 in Guntung in Riau Province. From the beginning, PSG''s main products have been coconut cream and desiccated coconut.</p>', '', 0, 1, 0, '', 1, 'Ismo Broto', '2016-01-04 15:44:00', 'Ismo Broto', '2016-01-09 14:36:59'),
('MakE5', 6, 'We believe in being First', 'We will conduct our businesses with Honesty and Integrity to achieve the best Quality Products &amp; Services. We trust our People to do their best and to Continuously Progress in Ideas and Processes to achieve the highest Customer Satisfaction.', '', 1, 0, 0, '', 1, 'Ismo Broto', '2016-01-13 15:39:17', 'Ismo Broto', '2016-01-13 15:49:55'),
('P3XSa', 4, 'a d a r a', '', '', 1, 0, 1, '', 1, 'Ismo Broto', '2016-01-16 11:13:08', '', '0000-00-00 00:00:00'),
('Pd65R', 1, 'PT Riau Sakti United Plantation', '<h2 style="opacity: 1; top: 0px;"><small style="opacity: 1; top: 0px;">PT Riau Sakti United Plantation (Industry)</small> Member of Sambu Group</h2>\r\n<p style="opacity: 0.7; top: 0px;">PT Pulau Sambu Guntung (PSG) was founded in 1983 in Guntung in Riau Province. From the beginning, PSG''s main products have been coconut cream and desiccated coconut.</p>', '', 0, 1, 0, '', 1, 'Ismo Broto', '2016-01-04 15:34:10', 'Ismo Broto', '2016-01-09 09:12:30'),
('riWDG', 4, 'Sin-Ind', '', '', 1, 0, 1, '', 1, 'Ismo Broto', '2016-01-09 13:39:22', '', '0000-00-00 00:00:00'),
('SKclt', 1, 'test', '<p>assasasas</p>', '', 1, 1, 0, '', 1, 'Ismo Broto', '2016-01-13 13:49:07', 'Ismo Broto', '2016-01-13 14:47:24'),
('Whyuy', 3, 'the First', '<p><span style="color: #999999; font-family: ''Noto Sans'', ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 13px; line-height: 18.5714px;">We believe in being First.</span></p>', 'entypo-thumbs-up', 1, 0, 0, '', 1, 'Ismo Broto', '2016-01-09 16:04:21', '', '0000-00-00 00:00:00'),
('YCG4O', 2, 'Quotes by Labolator', '<p><span style="color: #999999; font-family: ''Noto Sans'', ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 21px; font-style: italic; line-height: 30px; text-align: center;">Vivamus imperdiet felis consectetur onec eget orci adipiscing nunc.&nbsp;</span><br style="box-sizing: border-box; color: #999999; font-family: ''Noto Sans'', ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 21px; font-style: italic; line-height: 30px; text-align: center;" /><span style="color: #999999; font-family: ''Noto Sans'', ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 21px; font-style: italic; line-height: 30px; text-align: center;">Pellentesque fermentum, ante ac interdum ullamcorper.</span></p>', '', 1, 0, 0, 'Art Ramadani - co-founder at Laborator', 1, 'Ismo Broto', '2016-01-09 09:37:57', '', '0000-00-00 00:00:00'),
('YJ9fX', 2, 'COMMITMENT', '<p>dfsad sadsa <br /> sadas&nbsp;</p>', '', 1, 0, 0, 'Art Ramadani - co-founder at Laborator', 1, 'Ismo Broto', '2016-01-09 16:28:38', 'Ismo Broto', '2016-01-09 16:38:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_widget_type`
--

CREATE TABLE IF NOT EXISTS `tbl_widget_type` (
  `id_widget` int(11) NOT NULL,
  `name_widget` varchar(35) NOT NULL,
  `max_display` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(35) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tbl_widget_type`
--

INSERT INTO `tbl_widget_type` (`id_widget`, `name_widget`, `max_display`, `active`, `created_by`, `created_date`) VALUES
(1, 'Slider', 5, 1, 'Ismo Broto', '2016-01-08 09:35:38'),
(2, 'Quotes', 5, 1, 'Ismo Broto', '2016-01-08 09:36:23'),
(3, 'Tag Lines', 3, 1, 'Ismo Broto', '2016-01-08 09:36:45'),
(4, 'Product Tiles', 4, 1, 'Ismo Broto', '2016-01-08 09:36:45'),
(6, 'Philosophy', 1, 1, 'Ismo Broto', '2016-01-13 13:30:53');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_front_page_menu`
--
CREATE TABLE IF NOT EXISTS `vw_front_page_menu` (
`id1` int(11)
,`label1` varchar(100)
,`link1` varchar(100)
,`active1` tinyint(1)
,`id2` int(11)
,`label2` varchar(100)
,`link2` varchar(100)
,`active2` tinyint(1)
,`id3` int(11)
,`label3` varchar(100)
,`link3` varchar(100)
,`active3` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_join_type_category_product`
--
CREATE TABLE IF NOT EXISTS `vw_join_type_category_product` (
`id_category_product` int(11)
,`id_type` int(11)
,`name_type` varchar(50)
,`descrept_type` text
,`name_category_product` varchar(30)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_page_all_for_back`
--
CREATE TABLE IF NOT EXISTS `vw_page_all_for_back` (
`id1` int(11)
,`label1` varchar(100)
,`link1` varchar(100)
,`active1` tinyint(4)
,`id2` int(11)
,`label2` varchar(100)
,`link2` varchar(100)
,`active2` tinyint(4)
,`id3` int(11)
,`label3` varchar(100)
,`link3` varchar(100)
,`active3` tinyint(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_select_blog`
--
CREATE TABLE IF NOT EXISTS `vw_select_blog` (
`id_post` int(11)
,`id_category` int(11)
,`name_category` varchar(50)
,`active` tinyint(1)
,`count_post` int(11)
,`title_post` varchar(50)
,`post` text
,`publish` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
,`thumbnail` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_select_comment`
--
CREATE TABLE IF NOT EXISTS `vw_select_comment` (
`id_comment` int(11)
,`id_post` int(11)
,`title_post` varchar(50)
,`comment_by` varchar(35)
,`commnet_date` datetime
,`comment_email` varchar(35)
,`comment_value` text
,`approve` tinyint(1)
,`trash` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_select_content_profile`
--
CREATE TABLE IF NOT EXISTS `vw_select_content_profile` (
`kode_profile` varchar(6)
,`id_head` int(11)
,`title_profile` varchar(150)
,`post_profile` text
,`publish` tinyint(1)
,`layout_content` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
,`head_abbr` varchar(10)
,`head_descript` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_select_product`
--
CREATE TABLE IF NOT EXISTS `vw_select_product` (
`id_product` int(11)
,`type_product` int(11)
,`name_type` varchar(50)
,`descrept_type` text
,`category_product` int(11)
,`name_category_product` varchar(30)
,`name_product` varchar(50)
,`descript_product` text
,`thumbnail_product` tinyint(1)
,`banner_product` tinyint(1)
,`publish` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_select_vacancy`
--
CREATE TABLE IF NOT EXISTS `vw_select_vacancy` (
`id_vacancy` int(11)
,`id_category` int(11)
,`name_category` varchar(50)
,`active` tinyint(1)
,`count_vacancy` int(11)
,`title_jobs` varchar(50)
,`description` text
,`publish` tinyint(1)
,`closed_date` date
,`thumbnail` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_utl_list_user`
--
CREATE TABLE IF NOT EXISTS `vw_utl_list_user` (
`username` varchar(25)
,`nickname` varchar(35)
,`group_id` int(11)
,`group_name` varchar(30)
,`active` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_utl_menu_lv1`
--
CREATE TABLE IF NOT EXISTS `vw_utl_menu_lv1` (
`group_id` int(11)
,`group_name` varchar(30)
,`active` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
,`menu_id` int(11)
,`menu_name` varchar(100)
,`menu_label` varchar(100)
,`menu_icon` varchar(100)
,`menu_link` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_utl_menu_lv2`
--
CREATE TABLE IF NOT EXISTS `vw_utl_menu_lv2` (
`group_id` int(11)
,`group_name` varchar(30)
,`active` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
,`menu_id` int(11)
,`menu_name` varchar(100)
,`menu_label` varchar(100)
,`menu_icon` varchar(100)
,`menu_link` varchar(100)
,`menu_header` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_utl_menu_lv3`
--
CREATE TABLE IF NOT EXISTS `vw_utl_menu_lv3` (
`group_id` int(11)
,`group_name` varchar(30)
,`active` tinyint(1)
,`created_by` varchar(35)
,`created_date` datetime
,`updated_by` varchar(35)
,`updated_date` datetime
,`menu_id` int(11)
,`menu_name` varchar(100)
,`menu_label` varchar(100)
,`menu_icon` varchar(100)
,`menu_link` varchar(100)
,`menu_header` int(11)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_front_page_menu`
--
DROP TABLE IF EXISTS `vw_front_page_menu`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_front_page_menu` AS select `tbl_page_lv1`.`id_page` AS `id1`,`tbl_page_lv1`.`label_page` AS `label1`,`tbl_page_lv1`.`link_page` AS `link1`,`tbl_page_lv1`.`active` AS `active1`,`tbl_page_lv2`.`id_page` AS `id2`,`tbl_page_lv2`.`label_page` AS `label2`,`tbl_page_lv2`.`link_page` AS `link2`,`tbl_page_lv2`.`active` AS `active2`,`tbl_page_lv3`.`id_page` AS `id3`,`tbl_page_lv3`.`label_page` AS `label3`,`tbl_page_lv3`.`link_page` AS `link3`,`tbl_page_lv3`.`active` AS `active3` from ((`tbl_page_lv1` join `tbl_page_lv2` on((`tbl_page_lv1`.`id_page` = `tbl_page_lv2`.`header_page`))) join `tbl_page_lv3` on((`tbl_page_lv2`.`id_page` = `tbl_page_lv3`.`header_page`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_join_type_category_product`
--
DROP TABLE IF EXISTS `vw_join_type_category_product`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_join_type_category_product` AS select `tbl_product_category`.`id_category_product` AS `id_category_product`,`tbl_product_category`.`id_type` AS `id_type`,`tbl_product_type`.`name_type` AS `name_type`,`tbl_product_type`.`descrept_type` AS `descrept_type`,`tbl_product_category`.`name_category_product` AS `name_category_product`,`tbl_product_category`.`created_by` AS `created_by`,`tbl_product_category`.`created_date` AS `created_date`,`tbl_product_category`.`updated_by` AS `updated_by`,`tbl_product_category`.`updated_date` AS `updated_date` from (`tbl_product_type` join `tbl_product_category` on((`tbl_product_category`.`id_type` = `tbl_product_type`.`id_type`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_page_all_for_back`
--
DROP TABLE IF EXISTS `vw_page_all_for_back`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_page_all_for_back` AS select `vw_front_page_menu`.`id1` AS `id1`,`vw_front_page_menu`.`label1` AS `label1`,`vw_front_page_menu`.`link1` AS `link1`,`vw_front_page_menu`.`active1` AS `active1`,`vw_front_page_menu`.`id2` AS `id2`,`vw_front_page_menu`.`label2` AS `label2`,`vw_front_page_menu`.`link2` AS `link2`,`vw_front_page_menu`.`active2` AS `active2`,`vw_front_page_menu`.`id3` AS `id3`,`vw_front_page_menu`.`label3` AS `label3`,`vw_front_page_menu`.`link3` AS `link3`,`vw_front_page_menu`.`active3` AS `active3` from `vw_front_page_menu` union all select `tbl_page_lv1`.`id_page` AS `id1`,`tbl_page_lv1`.`label_page` AS `label1`,`tbl_page_lv1`.`link_page` AS `link1`,`tbl_page_lv1`.`active` AS `active1`,`tbl_page_lv2`.`id_page` AS `id2`,`tbl_page_lv2`.`label_page` AS `label2`,`tbl_page_lv2`.`link_page` AS `link2`,`tbl_page_lv2`.`active` AS `active2`,NULL AS `My_exp_2_NULL`,NULL AS `My_exp_3_NULL`,NULL AS `My_exp_4_NULL`,NULL AS `My_exp_5_NULL` from (`tbl_page_lv1` join `tbl_page_lv2` on((`tbl_page_lv1`.`id_page` = `tbl_page_lv2`.`header_page`))) where (not(`tbl_page_lv1`.`id_page` in (select `vw_front_page_menu`.`id1` from `vw_front_page_menu`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_select_blog`
--
DROP TABLE IF EXISTS `vw_select_blog`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_select_blog` AS select `tbl_blog_post`.`id_post` AS `id_post`,`tbl_blog_post`.`id_category` AS `id_category`,`tbl_blog_category`.`name_category` AS `name_category`,`tbl_blog_category`.`active` AS `active`,`tbl_blog_category`.`count_post` AS `count_post`,`tbl_blog_post`.`title_post` AS `title_post`,`tbl_blog_post`.`post` AS `post`,`tbl_blog_post`.`publish` AS `publish`,`tbl_blog_post`.`created_by` AS `created_by`,`tbl_blog_post`.`created_date` AS `created_date`,`tbl_blog_post`.`updated_by` AS `updated_by`,`tbl_blog_post`.`updated_date` AS `updated_date`,`tbl_blog_post`.`thumbnail` AS `thumbnail` from (`tbl_blog_category` join `tbl_blog_post` on((`tbl_blog_category`.`id_category` = `tbl_blog_post`.`id_category`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_select_comment`
--
DROP TABLE IF EXISTS `vw_select_comment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_select_comment` AS select `tbl_blog_comment`.`id_comment` AS `id_comment`,`tbl_blog_comment`.`id_post` AS `id_post`,`tbl_blog_post`.`title_post` AS `title_post`,`tbl_blog_comment`.`comment_by` AS `comment_by`,`tbl_blog_comment`.`commnet_date` AS `commnet_date`,`tbl_blog_comment`.`comment_email` AS `comment_email`,`tbl_blog_comment`.`comment_value` AS `comment_value`,`tbl_blog_comment`.`approve` AS `approve`,`tbl_blog_comment`.`trash` AS `trash` from (`tbl_blog_comment` join `tbl_blog_post` on((`tbl_blog_comment`.`id_post` = `tbl_blog_post`.`id_post`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_select_content_profile`
--
DROP TABLE IF EXISTS `vw_select_content_profile`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_select_content_profile` AS select `tbl_profile_post`.`kode_profile` AS `kode_profile`,`tbl_profile_post`.`id_head` AS `id_head`,`tbl_profile_post`.`title_profile` AS `title_profile`,`tbl_profile_post`.`post_profile` AS `post_profile`,`tbl_profile_post`.`publish` AS `publish`,`tbl_profile_post`.`layout_content` AS `layout_content`,`tbl_profile_post`.`created_by` AS `created_by`,`tbl_profile_post`.`created_date` AS `created_date`,`tbl_profile_post`.`updated_by` AS `updated_by`,`tbl_profile_post`.`updated_date` AS `updated_date`,`tbl_profile_head`.`head_abbr` AS `head_abbr`,`tbl_profile_head`.`head_descript` AS `head_descript` from (`tbl_profile_post` join `tbl_profile_head` on((`tbl_profile_post`.`id_head` = `tbl_profile_head`.`id_head_profile`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_select_product`
--
DROP TABLE IF EXISTS `vw_select_product`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_select_product` AS select `tbl_product`.`id_product` AS `id_product`,`tbl_product`.`type_product` AS `type_product`,`tbl_product_type`.`name_type` AS `name_type`,`tbl_product_type`.`descrept_type` AS `descrept_type`,`tbl_product`.`category_product` AS `category_product`,`tbl_product_category`.`name_category_product` AS `name_category_product`,`tbl_product`.`name_product` AS `name_product`,`tbl_product`.`descript_product` AS `descript_product`,`tbl_product`.`thumbnail_product` AS `thumbnail_product`,`tbl_product`.`banner_product` AS `banner_product`,`tbl_product`.`publish` AS `publish`,`tbl_product`.`created_by` AS `created_by`,`tbl_product`.`created_date` AS `created_date`,`tbl_product`.`updated_by` AS `updated_by`,`tbl_product`.`updated_date` AS `updated_date` from ((`tbl_product` join `tbl_product_type` on((`tbl_product`.`type_product` = `tbl_product_type`.`id_type`))) join `tbl_product_category` on((`tbl_product`.`category_product` = `tbl_product_category`.`id_category_product`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_select_vacancy`
--
DROP TABLE IF EXISTS `vw_select_vacancy`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_select_vacancy` AS select `tbl_vacancy_jobs`.`id_vacancy` AS `id_vacancy`,`tbl_vacancy_jobs`.`id_category` AS `id_category`,`tbl_vacancy_category`.`name_category` AS `name_category`,`tbl_vacancy_category`.`active` AS `active`,`tbl_vacancy_category`.`count_vacancy` AS `count_vacancy`,`tbl_vacancy_jobs`.`title_jobs` AS `title_jobs`,`tbl_vacancy_jobs`.`description` AS `description`,`tbl_vacancy_jobs`.`publish` AS `publish`,`tbl_vacancy_jobs`.`closed_date` AS `closed_date`,`tbl_vacancy_jobs`.`thumbnail` AS `thumbnail`,`tbl_vacancy_jobs`.`created_by` AS `created_by`,`tbl_vacancy_jobs`.`created_date` AS `created_date`,`tbl_vacancy_jobs`.`updated_by` AS `updated_by`,`tbl_vacancy_jobs`.`updated_date` AS `updated_date` from (`tbl_vacancy_jobs` join `tbl_vacancy_category` on((`tbl_vacancy_jobs`.`id_category` = `tbl_vacancy_category`.`id_category`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_utl_list_user`
--
DROP TABLE IF EXISTS `vw_utl_list_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_utl_list_user` AS select `tbl_utl_user`.`username` AS `username`,`tbl_utl_user`.`nickname` AS `nickname`,`tbl_utl_user`.`group_id` AS `group_id`,`tbl_utl_group_user`.`group_name` AS `group_name`,`tbl_utl_user`.`active` AS `active`,`tbl_utl_user`.`created_by` AS `created_by`,`tbl_utl_user`.`created_date` AS `created_date`,`tbl_utl_user`.`updated_by` AS `updated_by`,`tbl_utl_user`.`updated_date` AS `updated_date` from (`tbl_utl_user` join `tbl_utl_group_user` on((`tbl_utl_user`.`group_id` = `tbl_utl_group_user`.`group_id`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_utl_menu_lv1`
--
DROP TABLE IF EXISTS `vw_utl_menu_lv1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_utl_menu_lv1` AS select `tbl_utl_menu_access`.`group_id` AS `group_id`,`tbl_utl_group_user`.`group_name` AS `group_name`,`tbl_utl_group_user`.`active` AS `active`,`tbl_utl_group_user`.`created_by` AS `created_by`,`tbl_utl_group_user`.`created_date` AS `created_date`,`tbl_utl_group_user`.`updated_by` AS `updated_by`,`tbl_utl_group_user`.`updated_date` AS `updated_date`,`tbl_utl_menu_access`.`menu_id` AS `menu_id`,`tbl_utl_menu_lv1`.`menu_name` AS `menu_name`,`tbl_utl_menu_lv1`.`menu_label` AS `menu_label`,`tbl_utl_menu_lv1`.`menu_icon` AS `menu_icon`,`tbl_utl_menu_lv1`.`menu_link` AS `menu_link` from ((`tbl_utl_menu_access` join `tbl_utl_group_user` on((`tbl_utl_menu_access`.`group_id` = `tbl_utl_group_user`.`group_id`))) join `tbl_utl_menu_lv1` on((`tbl_utl_menu_access`.`menu_id` = `tbl_utl_menu_lv1`.`menu_id`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_utl_menu_lv2`
--
DROP TABLE IF EXISTS `vw_utl_menu_lv2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_utl_menu_lv2` AS select `tbl_utl_menu_access`.`group_id` AS `group_id`,`tbl_utl_group_user`.`group_name` AS `group_name`,`tbl_utl_group_user`.`active` AS `active`,`tbl_utl_group_user`.`created_by` AS `created_by`,`tbl_utl_group_user`.`created_date` AS `created_date`,`tbl_utl_group_user`.`updated_by` AS `updated_by`,`tbl_utl_group_user`.`updated_date` AS `updated_date`,`tbl_utl_menu_access`.`menu_id` AS `menu_id`,`tbl_utl_menu_lv2`.`menu_name` AS `menu_name`,`tbl_utl_menu_lv2`.`menu_label` AS `menu_label`,`tbl_utl_menu_lv2`.`menu_icon` AS `menu_icon`,`tbl_utl_menu_lv2`.`menu_link` AS `menu_link`,`tbl_utl_menu_lv2`.`menu_header` AS `menu_header` from ((`tbl_utl_menu_access` join `tbl_utl_group_user` on((`tbl_utl_menu_access`.`group_id` = `tbl_utl_group_user`.`group_id`))) join `tbl_utl_menu_lv2` on((`tbl_utl_menu_access`.`menu_id` = `tbl_utl_menu_lv2`.`menu_id`)));

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_utl_menu_lv3`
--
DROP TABLE IF EXISTS `vw_utl_menu_lv3`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_utl_menu_lv3` AS select `tbl_utl_menu_access`.`group_id` AS `group_id`,`tbl_utl_group_user`.`group_name` AS `group_name`,`tbl_utl_group_user`.`active` AS `active`,`tbl_utl_group_user`.`created_by` AS `created_by`,`tbl_utl_group_user`.`created_date` AS `created_date`,`tbl_utl_group_user`.`updated_by` AS `updated_by`,`tbl_utl_group_user`.`updated_date` AS `updated_date`,`tbl_utl_menu_access`.`menu_id` AS `menu_id`,`tbl_utl_menu_lv3`.`menu_name` AS `menu_name`,`tbl_utl_menu_lv3`.`menu_label` AS `menu_label`,`tbl_utl_menu_lv3`.`menu_icon` AS `menu_icon`,`tbl_utl_menu_lv3`.`menu_link` AS `menu_link`,`tbl_utl_menu_lv3`.`menu_header` AS `menu_header` from ((`tbl_utl_menu_access` join `tbl_utl_group_user` on((`tbl_utl_menu_access`.`group_id` = `tbl_utl_group_user`.`group_id`))) join `tbl_utl_menu_lv3` on((`tbl_utl_menu_access`.`menu_id` = `tbl_utl_menu_lv3`.`menu_id`)));

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_blog_category`
--
ALTER TABLE `tbl_blog_category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `tbl_blog_comment`
--
ALTER TABLE `tbl_blog_comment`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `tbl_blog_media`
--
ALTER TABLE `tbl_blog_media`
  ADD PRIMARY KEY (`kode_media`);

--
-- Indexes for table `tbl_blog_post`
--
ALTER TABLE `tbl_blog_post`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `tbl_page_footer`
--
ALTER TABLE `tbl_page_footer`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `tbl_page_lv1`
--
ALTER TABLE `tbl_page_lv1`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `tbl_page_lv2`
--
ALTER TABLE `tbl_page_lv2`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `tbl_page_lv3`
--
ALTER TABLE `tbl_page_lv3`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `tbl_product_category`
--
ALTER TABLE `tbl_product_category`
  ADD PRIMARY KEY (`id_category_product`);

--
-- Indexes for table `tbl_product_type`
--
ALTER TABLE `tbl_product_type`
  ADD PRIMARY KEY (`id_type`);

--
-- Indexes for table `tbl_profile_head`
--
ALTER TABLE `tbl_profile_head`
  ADD PRIMARY KEY (`id_head_profile`);

--
-- Indexes for table `tbl_profile_post`
--
ALTER TABLE `tbl_profile_post`
  ADD PRIMARY KEY (`kode_profile`);

--
-- Indexes for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  ADD PRIMARY KEY (`key_setting`);

--
-- Indexes for table `tbl_utl_group_user`
--
ALTER TABLE `tbl_utl_group_user`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `tbl_utl_menu_lv1`
--
ALTER TABLE `tbl_utl_menu_lv1`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `tbl_utl_menu_lv2`
--
ALTER TABLE `tbl_utl_menu_lv2`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `tbl_utl_menu_lv3`
--
ALTER TABLE `tbl_utl_menu_lv3`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `tbl_utl_user`
--
ALTER TABLE `tbl_utl_user`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `tbl_utl_user_log`
--
ALTER TABLE `tbl_utl_user_log`
  ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `tbl_vacancy_category`
--
ALTER TABLE `tbl_vacancy_category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `tbl_vacancy_jobs`
--
ALTER TABLE `tbl_vacancy_jobs`
  ADD PRIMARY KEY (`id_vacancy`);

--
-- Indexes for table `tbl_visitor`
--
ALTER TABLE `tbl_visitor`
  ADD PRIMARY KEY (`date_visit`);

--
-- Indexes for table `tbl_widget`
--
ALTER TABLE `tbl_widget`
  ADD PRIMARY KEY (`code_widget`);

--
-- Indexes for table `tbl_widget_type`
--
ALTER TABLE `tbl_widget_type`
  ADD PRIMARY KEY (`id_widget`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_blog_category`
--
ALTER TABLE `tbl_blog_category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_blog_comment`
--
ALTER TABLE `tbl_blog_comment`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_blog_post`
--
ALTER TABLE `tbl_blog_post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_page_footer`
--
ALTER TABLE `tbl_page_footer`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_page_lv1`
--
ALTER TABLE `tbl_page_lv1`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_page_lv2`
--
ALTER TABLE `tbl_page_lv2`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_page_lv3`
--
ALTER TABLE `tbl_page_lv3`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_product_category`
--
ALTER TABLE `tbl_product_category`
  MODIFY `id_category_product` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_product_type`
--
ALTER TABLE `tbl_product_type`
  MODIFY `id_type` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_profile_head`
--
ALTER TABLE `tbl_profile_head`
  MODIFY `id_head_profile` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  MODIFY `key_setting` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_utl_group_user`
--
ALTER TABLE `tbl_utl_group_user`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_utl_user_log`
--
ALTER TABLE `tbl_utl_user_log`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `tbl_vacancy_category`
--
ALTER TABLE `tbl_vacancy_category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_vacancy_jobs`
--
ALTER TABLE `tbl_vacancy_jobs`
  MODIFY `id_vacancy` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_widget_type`
--
ALTER TABLE `tbl_widget_type`
  MODIFY `id_widget` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
